package frame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author FAIZ
 */
import konek.konek;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class data_pemasukan extends javax.swing.JFrame {

   
    DefaultTableModel model;

    public data_pemasukan() {
        initComponents();
        String[] judul = {"kamar", "Nama", "Harga", "Tangal Masuk", "Tangal Keluar", "Pembayaran"};
        model = new DefaultTableModel(judul, 0);
        table_pemasukkan.setModel(model);
        tablePemasukkan();
    }

    private void tablePemasukkan() {

        DefaultTableModel tbl = new DefaultTableModel();

        tbl.addColumn("Id");
        tbl.addColumn("nama");
        tbl.addColumn("Harga");
        tbl.addColumn("Tgl_masuk");
        tbl.addColumn("Tgl_keluar");
        tbl.addColumn("total");
        table_pemasukkan.setModel(tbl);

        try {
            String query = "select * from tbl_data_pemasukan";
            Statement stm = konek.konekDB().createStatement();
            ResultSet res = stm.executeQuery(query);
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id"),
                    res.getString("nama"),
                    res.getString("Harga"),
                    res.getString("tgl_masuk"),
                    res.getString("tgl_keluar"),
                    res.getString("total"),});
            }
            table_pemasukkan.setModel(tbl);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public String kode_otomatis() {
        Random rad = new Random();
        int number = rad.nextInt(9999);
        String format = String.format("%03d", number);
        return "P" + format;
    }

    public void tanggal() {
        DateFormat tgl = new SimpleDateFormat("yyyy-MM-dd");
        String htgl = tgl.format(Calendar.getInstance().getTime());
        txttglmasuk.setText(htgl);
    }
    public void datatable() throws SQLException {
    DefaultTableModel tbl = new DefaultTableModel();
    tbl.addColumn("unit/kamar");
    tbl.addColumn("nama");
    tbl.addColumn("harga");
    tbl.addColumn("tgl_masuk");
    tbl.addColumn("tgl_keluar");  
    tbl.addColumn("total");
    table_pemasukkan.setModel(tbl);

    try (Statement statement = konek.GetConnection().createStatement();
         ResultSet res = statement.executeQuery("select * from tbl_data_pemasukan")) {

        while (res.next()) {
            tbl.addRow(new Object[]{
                    res.getString("Id"),
                    res.getString("nama"),
                    res.getString("Harga"),
                    res.getString("tgl_masuk"),
                    res.getString("tgl_keluar"),
                    res.getString("total"),
            });
        }

        // Set the model after adding all rows
        table_pemasukkan.setModel(tbl);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error retrieving data: " + e.getMessage());
    }
}
//     private void setTabelModel() {
//        DefaultTableModel model = (DefaultTableModel) table_pemasukkan.getModel();
//        model.addColumn("Unit/Kamar ");
//        model.addColumn("Nama");
//        model.addColumn("Harga");
//        model.addColumn("Tgl Masuk");
//        model.addColumn("Tgl Keluar");
//        model.addColumn("Total Pembayaran");
//
//    }
//
//    private void getData(DefaultTableModel model ) {
//        model.setRowCount(0);
//        
//        try{
//            int no = 1;
//            String sql = "SELECT * FROM tbl_data_pemasukan";
//            try (PreparedStatement st = conn.prepareStatement(sql)){
//                ResultSet rs = st.executeQuery();
//                
//                while (rs.next()){
//                    
//                    String id_kamar = rs.getString("id_kamar"),
//                    String nama_penghuni = rs.getString("nama_penghuni")
//                    String Harga= rs.getString("Harga"),
//                    String tgl_masuk =  rs.getString("tgl_masuk"),
//                    String tgl_tenggat = rs.getString("tgl_tenggat"),
//                    String total =  rs.getString("total"),
//
//                    
//                    Object[] rowData = {no++,id_kamar,nama_penghuni,Harga,tgl_masuk,tgl_tenggat};
//                    model.addRow(rowData);
//                }
//            }
//        }catch (Exception e){
//            JOptionPane.showMessageDialog(rootPane,e.toString());
//        }

//}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        txtkamar = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        txtharga = new javax.swing.JTextField();
        txtpembayaran = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btn_hapus = new javax.swing.JButton();
        btn_dashboard = new javax.swing.JButton();
        btn_datakamar = new javax.swing.JButton();
        btn_pengeluaran = new javax.swing.JButton();
        btn_tambah = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        table_pemasukkan = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        txt_cari = new javax.swing.JTextField();
        btn_cari = new javax.swing.JToggleButton();
        txttglmasuk = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jButton2 = new javax.swing.JButton();
        txttglkeluar = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkamar.setBackground(new java.awt.Color(237, 231, 227));
        getContentPane().add(txtkamar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, 80, 30));

        txtnama.setBackground(new java.awt.Color(237, 231, 227));
        getContentPane().add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 50, 130, 30));

        txtharga.setBackground(new java.awt.Color(237, 231, 227));
        getContentPane().add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 120, 30));

        txtpembayaran.setBackground(new java.awt.Color(237, 231, 227));
        getContentPane().add(txtpembayaran, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 130, 130, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel2.setText("Unit/kamar");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 48, -1, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel3.setText("Nama");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel4.setText("Harga");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 140, 40, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel5.setText("Tgl Masuk");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel6.setText("Tgl Keluar");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 88, -1, 30));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        jLabel7.setText("Total pembayaran");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 128, -1, 30));

        btn_hapus.setBackground(new java.awt.Color(114, 81, 58));
        btn_hapus.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        btn_hapus.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });
        getContentPane().add(btn_hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 420, 80, -1));

        btn_dashboard.setBackground(new java.awt.Color(237, 231, 227));
        btn_dashboard.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btn_dashboard.setText("Dashboard");
        btn_dashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dashboardActionPerformed(evt);
            }
        });
        getContentPane().add(btn_dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 160, 40));

        btn_datakamar.setBackground(new java.awt.Color(237, 231, 227));
        btn_datakamar.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        btn_datakamar.setText("Data Kamar");
        btn_datakamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_datakamarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_datakamar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 160, 30));

        btn_pengeluaran.setBackground(new java.awt.Color(237, 231, 227));
        btn_pengeluaran.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btn_pengeluaran.setText("Data Pengeluaran");
        btn_pengeluaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pengeluaranActionPerformed(evt);
            }
        });
        getContentPane().add(btn_pengeluaran, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 160, 40));

        btn_tambah.setBackground(new java.awt.Color(114, 81, 58));
        btn_tambah.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        btn_tambah.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah.setText("Tambah");
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });
        getContentPane().add(btn_tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 90, -1));

        table_pemasukkan.setBackground(new java.awt.Color(237, 231, 227));
        table_pemasukkan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Unit/Kamar", "Nama", "Harga", "Tgl Masuk", "Tgl Keluar", "Total"
            }
        ));
        table_pemasukkan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_pemasukkanMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table_pemasukkan);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 540, 200));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Logout");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 399, 60, 30));
        getContentPane().add(txt_cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 170, 150, 30));

        btn_cari.setText("Cari");
        btn_cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cariActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 170, -1, 30));

        txttglmasuk.setBackground(new java.awt.Color(237, 231, 227));
        txttglmasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttglmasukActionPerformed(evt);
            }
        });
        getContentPane().add(txttglmasuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 92, 90, 30));

        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 20, 30));

        jButton2.setBackground(new java.awt.Color(237, 231, 227));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        jButton2.setText("Data Penghuni");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 160, 30));

        txttglkeluar.setBackground(new java.awt.Color(237, 231, 227));
        getContentPane().add(txttglkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 90, 130, 30));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/pengeluaran (2).png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_pengeluaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pengeluaranActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new data_pengeluaran().setVisible(true);
    }//GEN-LAST:event_btn_pengeluaranActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        try {
            String id_Kamar = txtkamar.getText();
            String Nama = txtnama.getText();
            String Harga = txtharga.getText();
            String TglMasuk = txttglmasuk.getText();
            String TglKeluar = txttglkeluar.getText();
            String Pembayaran = txtpembayaran.getText();

            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost/kosabc", "root", "");
            cn.createStatement().executeUpdate("insert into tbl_data_pemasukan "
                    + "values('" + id_Kamar + "','" + Nama + "','" + Harga + "','" + TglMasuk + "','" + TglKeluar + "','" + Pembayaran + "')");
            JOptionPane.showMessageDialog(null, "DATA BERHASIL DI TAMBAH");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }

        DefaultTableModel model;
        tablePemasukkan();
        txtkamar.setText("");
        txtnama.setText("");
        txtharga.setText("");
        txttglmasuk.setText("");
        txttglkeluar.setText("");
        txtpembayaran.setText("");

    }//GEN-LAST:event_btn_tambahActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
       String id = (String) txtkamar.getText();
    try {
    Statement statement = (Statement) konek.GetConnection().createStatement();
    statement.executeUpdate("delete from tbl_data_pemasukan where Id='" + id + "';");
    JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
    txtkamar.setText("");
    txtnama.setText("");
    txtharga.setText("");
    txttglmasuk.setText("");
    txttglkeluar.setText("");
     txtpembayaran.setText("");
} catch (SQLException e) {
    // Log the exception details
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Data Gagal: " + e.getMessage());
}
     try {
               datatable();
           } catch (SQLException ex) {
               Logger.getLogger(data_pemasukan.class.getName()).log(Level.SEVERE, null, ex);
           }
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        int pilih = JOptionPane.showConfirmDialog(null, "apakah anda ingin log out?",
                "konfirmasi", JOptionPane.OK_CANCEL_OPTION);
        if (pilih == JOptionPane.OK_OPTION) {
            this.setVisible(false);
            new halaman_utama().setVisible(true);
        } else {
            JOptionPane.getRootFrame();
        }
    }//GEN-LAST:event_jLabel9MouseClicked

    private void btn_dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dashboardActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new dashboard().setVisible(true);
    }//GEN-LAST:event_btn_dashboardActionPerformed

    private void btn_datakamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_datakamarActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new data_kamar().setVisible(true);
    }//GEN-LAST:event_btn_datakamarActionPerformed

    private void btn_cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cariActionPerformed
        // TODO add your handling code here:
        try {
            Statement stm = konek.konekDB().createStatement();
            ResultSet res = stm.executeQuery("select * from tbl_data_pemasukan where id='" + txt_cari.getText() + "'");
            DefaultTableModel tbl = new DefaultTableModel();
            tbl.addColumn("id_kamar");
            tbl.addColumn("nama_penghuni");
            tbl.addColumn("Harga");
            tbl.addColumn("Tgl_Masuk");
            tbl.addColumn("Tgl_Tenggat");
            tbl.addColumn("total");

            table_pemasukkan.setModel(tbl);
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("id"),
                    res.getString("nama"),
                    res.getString("tgl_masuk"),
                    res.getString("tgl_keluar"),
                    res.getString("total")});
                table_pemasukkan.setModel(tbl);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_cariActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        if (jRadioButton1.isSelected()) {
            tanggal();
        } else {
            txttglmasuk.setText(null);
        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new data_penghuni().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void table_pemasukkanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_pemasukkanMouseClicked
        DefaultTableModel tblModel = (DefaultTableModel)table_pemasukkan.getModel();
        
        String tblkamar = tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 0).toString();
        String tblnama= tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 1).toString();
        String tblharga = tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 2).toString();
        String tbltglmasuk  = tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 3).toString();
        String tbltglkeluar = tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 4).toString();
        String tblpembayaran = tblModel.getValueAt(table_pemasukkan.getSelectedRow(), 5).toString();
       
        txtkamar.setText(tblkamar);
        txtnama.setText(tblnama);
        txtharga.setText(tblharga);
        txttglmasuk.setText(tbltglmasuk );
        txttglkeluar.setText(tbltglkeluar );
        txtpembayaran.setText(tblpembayaran );


    }//GEN-LAST:event_table_pemasukkanMouseClicked

    private void txttglmasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttglmasukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttglmasukActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data_pemasukan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data_pemasukan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data_pemasukan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data_pemasukan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new data_pemasukan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_cari;
    private javax.swing.JButton btn_dashboard;
    private javax.swing.JButton btn_datakamar;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_pengeluaran;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable table_pemasukkan;
    private javax.swing.JTextField txt_cari;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtkamar;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtpembayaran;
    private javax.swing.JTextField txttglkeluar;
    private javax.swing.JTextField txttglmasuk;
    // End of variables declaration//GEN-END:variables

    private void tampilkan() throws SQLException {
        int row = table_pemasukkan.getRowCount();
        for (int a = 0; a < row; a++) {
            model.removeRow(0);
        }
        Connection cn = DriverManager.getConnection("jdbc:mysql://localhost/kosabc", "root", "");
        ResultSet rs = cn.createStatement().executeQuery("SELECT * FROM tbl_data_pemasukan");
        while (rs.next()) {
            String data[] = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)};
            model.addRow(data);
        }
    }

}
