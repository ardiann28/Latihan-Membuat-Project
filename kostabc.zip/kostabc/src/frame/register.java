
package frame;


import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import konek.konek;
import java.sql.SQLException;
import java.sql.Statement;


public class register extends javax.swing.JFrame {

    /**
     * Creates new form register
     */
    public register() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_username = new javax.swing.JTextField();
        txt_password = new javax.swing.JPasswordField();
        txt_konfirpw = new javax.swing.JPasswordField();
        btn_cancel = new javax.swing.JButton();
        btn_submit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_username.setBackground(new java.awt.Color(114, 81, 58));
        txt_username.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(txt_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 160, 320, 40));

        txt_password.setBackground(new java.awt.Color(114, 81, 58));
        txt_password.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(txt_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, 320, 40));

        txt_konfirpw.setBackground(new java.awt.Color(114, 81, 58));
        txt_konfirpw.setForeground(new java.awt.Color(255, 255, 255));
        txt_konfirpw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_konfirpwActionPerformed(evt);
            }
        });
        getContentPane().add(txt_konfirpw, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 340, 320, 40));

        btn_cancel.setBackground(new java.awt.Color(114, 81, 58));
        btn_cancel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_cancel.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 110, 40));

        btn_submit.setBackground(new java.awt.Color(114, 81, 58));
        btn_submit.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_submit.setForeground(new java.awt.Color(255, 255, 255));
        btn_submit.setText("Submit");
        btn_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_submitActionPerformed(evt);
            }
        });
        getContentPane().add(btn_submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, 110, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/komponen/Salinan dari PROJEK KOST (750 x 450 piksel) (1).png"))); // NOI18N
        jLabel2.setText("nn");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_submitActionPerformed
       try {
    String sql = "INSERT INTO tbl_login (username, password) VALUES (?, ?)";
    Connection conn = konek.konekDB();
    
    try (PreparedStatement pst = conn.prepareStatement(sql)) {
        // Check if passwords match before inserting
        if (txt_password.getText().equals(txt_konfirpw.getText())) {
            pst.setString(1, txt_username.getText());
            pst.setString(2, txt_password.getText()); // Hash the password before storing

            pst.executeUpdate(); // Execute SQL statement to store data

            JOptionPane.showMessageDialog(null, "DATA BERHASIL DI REGISTRASI");
            this.setVisible(false);
            new login().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Password and confirmation do not match.");
        }
    }
} catch (SQLException e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}

    }//GEN-LAST:event_btn_submitActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        new login().setVisible(true);
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void txt_konfirpwActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_konfirpwActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_konfirpwActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_submit;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField txt_konfirpw;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_username;
    // End of variables declaration//GEN-END:variables
}
