/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package konek;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author ibnu malik
 */
public class konek {
    private static Connection mysqlkonek;

    public static Connection konekDB() {
        try {
            String url = "jdbc:mysql://localhost:3306/kosabc"; // URL of the database
            String username = "root"; // Database username
            String password = ""; // Database password

            mysqlkonek = DriverManager.getConnection(url, username, password);
            return mysqlkonek;
        } catch (SQLException e) { // Print the exception for debugging
            // Print the exception for debugging
            System.err.println("Koneksi gagal " + e.getMessage());
            return null; // Return null to indicate connection failure
        }
    }

    public static Connection getKonek() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    com.mysql.jdbc.Connection con;
    private final String driver = "com.mysql.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost/kosabc";
    private final String user = "root";
    private final String pwd = "";
    
    public void Koneksi() {
        try {
            Class.forName(driver);
            con = (com.mysql.jdbc.Connection) DriverManager.getConnection(url, user, pwd);
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Error:\nKoneksi Data Gagal\n" + e.getMessage());
        }
    }
    
    public ResultSet ambilData(String SQL) {
        try {
            con = (com.mysql.jdbc.Connection) DriverManager.getConnection(url, user, pwd);
            Statement st = (Statement) con.createStatement();
            return st.executeQuery(SQL);
        } catch (Exception e) {
            System.out.println("Error:\nPengecekan Data Gagal Diakses!");
            e.printStackTrace();
            return null;
        }
    }
    
    public void aksi(String SQL) {
        try {
            Statement st = (Statement) con.createStatement();
            st.executeUpdate(SQL);
        } catch (Exception e) {
            System.out.println("Error:\nAksi Gagal Diakses!");
            e.printStackTrace();
        }
    }

    Object getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     private static Connection Koneksi;
    
    public static Connection GetConnection()throws SQLException{
        if (Koneksi==null){
            
             Koneksi=DriverManager.getConnection("jdbc:mysql://localhost:3306/kosabc","root","");
        }
        return Koneksi;
    
}
}
